SELECT DISTINCT cliente.nome, gerente.nome, contacorrente.saldo, poupanca.saldo FROM cliente, gerente, contacorrente, poupanca
WHERE cliente.idcliente = contacorrente.idcliente AND cliente.idcliente = poupanca.idcliente
ORDER BY contacorrente.saldo
;

DROP TRIGGER tglogCC
;

SELECT  * FROM tipoconta; 

SELECT * FROM contacorrente;

SELECT * FROM movimentacao;

SELECT * FROM poupanca;

UPDATE poupanca
SET saldo = 2000.00
WHERE idpoupanca = 2
;

UPDATE contacorrente
SET saldo = 1000.00
WHERE idconta = 1
;