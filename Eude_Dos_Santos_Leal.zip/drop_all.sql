
DROP TRIGGER IF EXISTS tglogCC;

DROP TABLE IF EXISTS contacorrente;

DROP TABLE IF EXISTS movimentacao;

DROP TABLE IF EXISTS poupanca;

DROP TABLE IF EXISTS tipoconta;

DROP TABLE IF EXISTS tipotransacao;

DROP TABLE IF EXISTS cliente;

DROP TABLE IF EXISTS gerente;